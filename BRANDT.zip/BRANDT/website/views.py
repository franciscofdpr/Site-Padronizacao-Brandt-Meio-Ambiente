from django.shortcuts import render, HttpResponse

# Create your views here.

def login(request):
    return render(request,"website/login.html")

def home(request):
    return render(request,"website/home.html")
    
def inicio(request):
    return render(request,"website/inicio.html")

